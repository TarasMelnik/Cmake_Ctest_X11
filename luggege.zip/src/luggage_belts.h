
#pragma once

// extern "C" {
// #include <X11/Xlib.h>
// #include <X11/Xutil.h>
// #include <X11/Xos.h>
// }

// #include <iostream>
// #include <cstdlib>
// #include <cstdio>
// #include <cstring>
// #include <ctime>
// #include <thread>
// #include <queue>
// #include <array>
#include "Luggage.h"
#include "Belts.h"




#define NO_LUGGAGE "No luggage"


#define BELTS_LEN 10.0f
#define LUGGAGE_SPEED_MULT 0.00017f


// using namespace std;
